> [!IMPORTANT]
> Atualizar est: sexta-feira

> [!IMPORTANT]
> desculpe pelo mau português estou usando um tradutor

<div align="center">
  <img src="https://github.com/ilytobias/Khan-Destroyer/assets/165577429/fcd7fa24-a62c-46c8-bc02-78463bd4c64a" width="500" height="500"></img>

  (logotipo feito por [orphanlol](https://github.com/orphanlol))

  ### Discord

  Junte-se ao **[Discord](https://discord.gg/pujbPqMyPF)** para suporte e informações! Nossa comunidade é bem-vinda para uma discussão amigável sobre Khan Destroyer.

  Você também pode fornecer sugestões.
</div>

# Opções de download
## Userscripts
**Você só pode executar um script de usuário por vez ou ambos serão quebrados.**
<br>

* Obtenha um provedor de userscript como [Tampermoney](https://chromewebstore.google.com/detail/tampermonkey/dhdgffkkebhmkfjojejmpbldmpobfkfo) Or [Greasyfork](https://addons.mozilla.org/en-US/firefox/addon/greasemonkey/).
* Escolha um script de usuário [Responder Substituir](https://github.com/ilytobias/Khan-Destroyer/raw/main/cheats/overwrite.user.js), [Revelador de respostas](https://github.com/ilytobias/Khan-Destroyer/raw/main/cheats/revealer.user.js) (
Para mais seleção, use o método Bookmarklet.)
* Faça uma aula de Khan e ela será carregada.
  
## Bookmarklet (método preferido)

* Escolha um hack [Responder Substituir](https://github.com/ilytobias/Khan-Destroyer/blob/main/portuguese/truques/resposta_substituir.md), [Resposta automática](https://github.com/ilytobias/Khan-Destroyer/blob/main/portuguese/truques/resposta-automatica.md), [Revelador de respostas](https://github.com/ilytobias/Khan-Destroyer/blob/main/portuguese/truques/mostrar_resposta.md), ou se você sabe o que está fazendo, pode experimentar o [Energy Point Farmer](https://github.com/ilytobias/Khan-Destroyer/blob/main/portuguese/truques/farmer.md)
* Siga as instruções na página que ela abre. 

# Sobre

## Seguro?
Sim, isso é seguro, não houve nenhum caso registrado de banimento de uma conta Khan por hacks (pelo menos por enquanto). <br>
Além disso, se você está perguntando se isso é um vírus, o código é 100% aberto para sempre, então você pode examinar o código para ver por si mesmo. <br>

## Apoiar
Marque o repositório com estrela ou entre no discord. Adicionarei um nível pago mais tarde (hacks básicos ainda gratuitos)
<br>
![image](https://github.com/ilytobias/Khan-Destroyer/assets/165577429/673061fc-c131-423b-a81b-daf862b96493)

