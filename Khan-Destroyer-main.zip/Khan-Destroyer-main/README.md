> [!IMPORTANT]
> [GitHub traduzido para o português](https://github.com/ilytobias/Khan-Destroyer/tree/main/portuguese)

<div align="center">
  <img src="https://github.com/ilytobias/Khan-Destroyer/assets/165577429/fcd7fa24-a62c-46c8-bc02-78463bd4c64a" width="500" height="500"></img>

  (logo made by [orphanlol](https://github.com/orphanlol))

  ### Discord

  Join the **[Discord](https://discord.gg/pujbPqMyPF)** for support and information! Our community is welcome to friendly discussion about Khan Destroyer.

  You can also provide suggestions.
</div>

# Download Options
## Userscripts
**You can only run one userscript at a time or else it will break both.**
<br>

* Get a userscript provider like [Tampermoney](https://chromewebstore.google.com/detail/tampermonkey/dhdgffkkebhmkfjojejmpbldmpobfkfo) Or [Greasyfork](https://addons.mozilla.org/en-US/firefox/addon/greasemonkey/).
* Choose a userscript [Answer Overwrite](https://github.com/ilytobias/Khan-Destroyer/raw/main/cheats/overwrite.user.js), [Answer Revealer](https://github.com/ilytobias/Khan-Destroyer/raw/main/cheats/revealer.user.js) (For more selection please use the Bookmarklet method.)
* Go on a Khan lesson and it will be loaded
  
## Bookmarklet (perfered method)

* Choose a hack [Answer Overwrite](https://github.com/ilytobias/Khan-Destroyer/blob/main/cheats/answer_overwrite.md), [Auto Answer](https://github.com/ilytobias/Khan-Destroyer/blob/main/cheats/auto_answer.md), [Answer Revealer](https://github.com/ilytobias/Khan-Destroyer/blob/main/cheats/show_answers.md), [Minute Farmer](https://github.com/ilytobias/Khan-Destroyer/blob/main/cheats/minute_farmer.md), or if you know what you're doing you can try the [Energy Point Farmer](https://github.com/ilytobias/Khan-Destroyer/blob/main/cheats/farmer.md)
* Follow directions on the page it opens. 

# About

## Safe?
Yes this is safe, there have been **zero** recorded cases of a Khan account being banned for hacks (at least for now). <br>
Also if you're asking if this is a virus it is 100% open sourced forever so you can look through the code to see for yourself. <br>

## Support
Star the repo, or join the discord. I will be adding a paid tier later (base hacks still free)
<br>
![image](https://github.com/ilytobias/Khan-Destroyer/assets/165577429/673061fc-c131-423b-a81b-daf862b96493)

